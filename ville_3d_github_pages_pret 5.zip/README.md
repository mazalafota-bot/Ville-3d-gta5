# Ville 3D — Jeu mobile

Jeu 3D open-world jouable dans un navigateur.

## Publication avec GitHub Pages

1. Créer un dépôt GitHub public.
2. Envoyer `index.html` à la racine du dépôt.
3. Aller dans **Settings → Pages**.
4. Choisir **Deploy from a branch**.
5. Choisir la branche **main** et le dossier **/(root)**.
6. Enregistrer.
7. Attendre quelques minutes puis ouvrir l'adresse GitHub Pages.

## Commandes mobile

- Joystick gauche : déplacement
- Glisser à droite : caméra
- E : interaction / véhicules / avion
- SAUT : sauter
- COURSE : courir

Le jeu charge Three.js depuis un CDN, donc une connexion Internet est nécessaire.
